$ErrorActionPreference = "Stop"
$Listener = [System.Net.HttpListener]::new()
$Listener.Prefixes.Add("http://127.0.0.1:38473/")

function Send-Response {
  param(
    [System.Net.HttpListenerResponse]$Response,
    [int]$StatusCode,
    [string]$Text
  )

  $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
  $Response.StatusCode = $StatusCode
  $Response.ContentType = "text/plain; charset=utf-8"
  $Response.ContentLength64 = $bytes.Length
  $Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $Response.Close()
}

$Listener.Start()
Write-Host "Discord alerts are ready for Campus Housing Monitor."
Write-Host "Keep this window open while monitoring. Press Ctrl+C to stop."

try {
  while ($Listener.IsListening) {
    $context = $Listener.GetContext()
    $request = $context.Request
    $response = $context.Response

    try {
      if ($request.HttpMethod -eq "GET" -and $request.Url.AbsolutePath -eq "/health") {
        Send-Response $response 200 "ready"
        continue
      }

      if ($request.HttpMethod -ne "POST" -or $request.Url.AbsolutePath -ne "/discord") {
        Send-Response $response 404 "not found"
        continue
      }

      $reader = [System.IO.StreamReader]::new($request.InputStream, $request.ContentEncoding)
      $input = $reader.ReadToEnd() | ConvertFrom-Json
      $reader.Close()

      $title = [string]$input.title
      $message = [string]$input.message
      $pingEveryone = [bool]$input.pingEveryone
      $webhookUrl = [string]$input.webhookUrl
      $validWebhook = $webhookUrl -match '^https://(discord\.com|discordapp\.com)/api/webhooks/\d+/[^/]+$'
      if (-not $validWebhook -or -not $title -or -not $message -or $title.Length -gt 200 -or $message.Length -gt 1500) {
        Send-Response $response 400 "invalid alert"
        continue
      }

      $content = if ($pingEveryone) { "@everyone`n**$title**`n$message" } else { "**$title**`n$message" }
      $allowedMentions = if ($pingEveryone) { @{ parse = @("everyone") } } else { @{ parse = @() } }
      $payload = @{
        content = $content
        allowed_mentions = $allowedMentions
      } | ConvertTo-Json -Depth 4

      Invoke-RestMethod -Uri "${webhookUrl}?wait=true" -Method Post -ContentType "application/json" -Body $payload | Out-Null
      Send-Response $response 200 "sent"
    } catch {
      Send-Response $response 502 "Discord could not accept the message. Check the webhook URL and channel."
    }
  }
} finally {
  $Listener.Stop()
  $Listener.Close()
}
