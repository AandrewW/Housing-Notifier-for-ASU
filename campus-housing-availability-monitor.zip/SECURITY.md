# Security

## Discord webhook URLs

Discord webhook URLs are credentials. Do not commit one to this repository,
include one in an issue, or post one in a screenshot.

If a webhook is exposed:

1. Delete it in Discord.
2. Create a replacement.
3. Save the replacement in the extension popup.

The extension stores the webhook in browser-local extension storage. The local
Discord helper accepts it only from the extension over `127.0.0.1` and sends
the alert to Discord.

## Reporting a security issue

Do not include credentials, signed-in housing links, `UrlToken` values, or
personal account information in a public GitHub issue. Share only the minimum
details needed to reproduce the problem.
