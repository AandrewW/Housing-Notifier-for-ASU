const ALARM_NAME = "campus-housing-check";
const RELAY_URL = "http://127.0.0.1:38473/discord";
const CAMPUS_OPTIONS = [
  { name: "Polytechnic", terms: ["polytechnic"] },
  { name: "Tempe", terms: ["tempe"] },
  { name: "Downtown Phoenix", terms: ["downtown phoenix", "downtown"] },
  { name: "West", terms: ["west valley", "west"] }
];
const DEFAULT_CAMPUSES = CAMPUS_OPTIONS.map((campus) => campus.name);
const scansInProgress = new Set();
const discordAlertsInProgress = new Set();
const DEFAULTS = {
  enabled: false,
  tabId: null,
  intervalMinutes: 5,
  keywords: DEFAULT_CAMPUSES,
  alertOnChange: false,
  baselineHash: "",
  lastChecked: "",
  lastStatus: "Not monitoring",
  lastMatch: "",
  previousSelectableMatches: [],
  desktopAlertFingerprint: "",
  discordAlertFingerprint: "",
  discordWebhookUrl: "",
  campusOptionsInitialized: false
};

async function getState() {
  return { ...DEFAULTS, ...(await chrome.storage.local.get(DEFAULTS)) };
}

async function schedule(state) {
  await chrome.alarms.clear(ALARM_NAME);
  if (state.enabled) {
    await chrome.alarms.create(ALARM_NAME, {
      delayInMinutes: state.intervalMinutes,
      periodInMinutes: state.intervalMinutes
    });
  }
}

async function notify(title, message) {
  try {
    await chrome.notifications.create({
      type: "basic",
      iconUrl: "icon.png",
      title,
      message,
      priority: 2,
      requireInteraction: true
    });
    return true;
  } catch {
    // Opera can reject desktop notification images. Discord alerts must continue.
    return false;
  }
}

function isDiscordWebhook(url) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "https:" &&
      ["discord.com", "discordapp.com"].includes(parsed.hostname) &&
      /^\/api\/webhooks\/\d+\/[^/]+$/.test(parsed.pathname);
  } catch {
    return false;
  }
}

async function postDiscord(webhookUrl, title, message, pingEveryone = false) {
  if (!webhookUrl) {
    throw new Error("Add a Discord webhook in the extension popup.");
  }

  let response;
  try {
    response = await fetch(RELAY_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        webhookUrl,
        title,
        message,
        pingEveryone
      })
    });
  } catch {
    throw new Error("Discord alerts are not running. Open start-discord-alerts.cmd.");
  }

  if (!response.ok) {
    const body = await response.text();
    throw new Error(body || "Discord could not accept the message.");
  }
}

async function verifyDiscordWebhook(webhookUrl) {
  let response;
  try {
    response = await fetch("http://127.0.0.1:38473/health");
  } catch {
    throw new Error("Discord alerts are not running. Open start-discord-alerts.cmd.");
  }
  if (!response.ok) throw new Error("Discord alerts are still starting. Try again in a moment.");
}

async function stopWithStatus(status) {
  await chrome.storage.local.set({ enabled: false, lastStatus: status });
  await chrome.alarms.clear(ALARM_NAME);
}

async function scanFrame(campuses) {
  const selectableMatches = [];
  const controls = document.querySelectorAll(
    "button, input[type='button'], input[type='submit'], a"
  );

  for (const control of controls) {
    const controlText = `${control.innerText || ""} ${control.value || ""}`
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
    if (!controlText.includes("select")) continue;

    let container = control.parentElement;
    for (let depth = 0; container && depth < 6; depth += 1) {
      const containerText = container.innerText?.replace(/\s+/g, " ").trim() || "";
      const selectControlCount = Array.from(container.querySelectorAll(
        "button, input[type='button'], input[type='submit'], a"
      )).filter((candidate) => {
        const text = `${candidate.innerText || ""} ${candidate.value || ""}`.toLowerCase();
        return text.includes("select");
      }).length;
      const normalizedContainer = containerText.toLowerCase();
      const match = campuses.find((campus) =>
        campus.terms.some((term) => normalizedContainer.includes(term))
      );
      if (
        match &&
        containerText.length <= 800 &&
        selectControlCount === 1 &&
        !selectableMatches.includes(match.name)
      ) {
        selectableMatches.push(match.name);
        break;
      }
      container = container.parentElement;
    }
  }

  const text = document.body?.innerText
    ?.replace(/\s+/g, " ")
    .trim()
    .toLowerCase() || "";
  const matches = campuses
    .filter((campus) => campus.terms.some((term) => text.includes(term)))
    .map((campus) => campus.name);
  const hashBuffer = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  const hash = Array.from(new Uint8Array(hashBuffer))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
  return { hash, matches, selectableMatches };
}

async function scanMonitoredTab(tabId) {
  try {
    const state = await getState();
    const selectedCampuses = CAMPUS_OPTIONS.filter((campus) =>
      state.keywords.includes(campus.name)
    );
    const results = await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: scanFrame,
      args: [selectedCampuses]
    });
    const frameResults = results
      .map((entry) => entry.result)
      .filter(Boolean);
    if (!frameResults.length) throw new Error("The page did not return scan results.");

    const selectableMatches = [...new Set(
      frameResults.flatMap((result) => result.selectableMatches || [])
    )];
    const matches = [...new Set(frameResults.flatMap((result) => result.matches || []))];
    const hash = frameResults.map((result) => result.hash).sort().join("|");
    await handlePageResult({ selectableMatches, matches, hash }, { id: tabId });
    return {
      ok: true,
      framesScanned: frameResults.length,
      selectableMatches
    };
  } catch (error) {
    await chrome.storage.local.set({
      lastStatus: `Scan failed: ${error.message}`
    });
    return { ok: false, error: error.message };
  }
}

async function scanAfterLoad(tabId) {
  if (scansInProgress.has(tabId)) return;
  scansInProgress.add(tabId);
  await chrome.storage.local.set({ lastStatus: "Waiting for housing page to load..." });
  try {
    const state = await getState();
    if (!state.enabled || state.tabId !== tabId) return;
    const result = await scanMonitoredTab(tabId);
    if (!result.ok) {
      await chrome.storage.local.set({
        lastStatus: `Automatic scan failed: ${result.error}`
      });
    }
  } finally {
    scansInProgress.delete(tabId);
  }
}

function isAllowedHousingHost(url) {
  try {
    const hostname = new URL(url).hostname;
    return hostname.endsWith(".starrezhousing.com");
  } catch {
    return false;
  }
}

chrome.runtime.onInstalled.addListener(async (details) => {
  const state = await getState();
  if (details.reason === "update") {
    const oldDefaults = ["available", "select room", "choose room", "beds available"];
    const polytechnicOnly = ["Polytechnic"];
    if (
      JSON.stringify(state.keywords) === JSON.stringify(oldDefaults) ||
      JSON.stringify(state.keywords) === JSON.stringify(polytechnicOnly)
    ) {
      state.keywords = ["Polytechnic", "Tempe", "West"];
      state.alertOnChange = false;
    }
    state.desktopAlertFingerprint = "";
    state.discordAlertFingerprint = "";
    state.previousSelectableMatches = [];
  }
  if (!state.campusOptionsInitialized) {
    state.keywords = [...new Set([
      ...state.keywords.filter((campus) => DEFAULT_CAMPUSES.includes(campus)),
      "Downtown Phoenix"
    ])];
    state.campusOptionsInitialized = true;
  }
  state.alertOnChange = false;
  await chrome.storage.local.set(state);
  await chrome.storage.local.remove(["url", "alertFingerprint"]);
  await schedule(state);
});

chrome.runtime.onStartup.addListener(async () => {
  await schedule(await getState());
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;

  const state = await getState();
  if (!state.enabled || !state.tabId) return;

  try {
    const tab = await chrome.tabs.get(state.tabId);
    if (!tab.url?.startsWith("https://") || !isAllowedHousingHost(tab.url)) {
      await stopWithStatus("Stopped: the monitored tab left the supported housing portal.");
      return;
    }

    await chrome.storage.local.set({ lastStatus: "Refreshing housing page..." });
    await chrome.tabs.reload(state.tabId);
  } catch {
    await stopWithStatus("Stopped: monitored tab was closed.");
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status !== "complete") return;
  return getState().then((state) => {
    if (state.enabled && state.tabId === tabId) {
      return scanAfterLoad(tabId);
    }
  });
});

chrome.webNavigation.onDOMContentLoaded.addListener((details) => {
  if (details.frameId !== 0) return;
  return getState().then((state) => {
    if (state.enabled && state.tabId === details.tabId) {
      return scanAfterLoad(details.tabId);
    }
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "startMonitoring") {
    startMonitoring(message).then(sendResponse);
    return true;
  }

  if (message.type === "stopMonitoring") {
    stopWithStatus("Paused").then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === "saveSettings") {
    saveSettings(message).then(sendResponse);
    return true;
  }

  if (message.type === "testDiscord") {
    testDiscord(message.discordWebhookUrl).then(sendResponse);
    return true;
  }

  if (message.type === "pingDetectedCampuses") {
    pingDetectedCampuses().then(sendResponse);
    return true;
  }

  if (message.type === "scanNow") {
    scanNow().then(sendResponse);
    return true;
  }

  if (message.type === "focusMonitoredTab") {
    focusMonitoredTab().then(sendResponse);
    return true;
  }
});

async function startMonitoring({ tabId, url, intervalMinutes, keywords }) {
  if (!isAllowedHousingHost(url)) {
    return { ok: false, error: "Open the supported Choose My Community page before starting." };
  }
  const selectedCampuses = Array.isArray(keywords)
    ? keywords.filter((campus) => DEFAULT_CAMPUSES.includes(campus))
    : DEFAULT_CAMPUSES;
  if (!selectedCampuses.length) {
    return { ok: false, error: "Choose at least one campus before starting." };
  }

  const state = {
    enabled: true,
    tabId,
    intervalMinutes,
    keywords: selectedCampuses,
    alertOnChange: false,
    baselineHash: "",
    desktopAlertFingerprint: "",
    discordAlertFingerprint: "",
    previousSelectableMatches: [],
    lastStatus: "Waiting for first page scan..."
  };
  await chrome.storage.local.set(state);
  await schedule(state);
  await chrome.tabs.reload(tabId);
  return { ok: true };
}

async function saveSettings({ intervalMinutes, keywords, discordWebhookUrl }) {
  if (
    discordWebhookUrl !== undefined &&
    discordWebhookUrl !== "" &&
    !isDiscordWebhook(discordWebhookUrl)
  ) {
    return {
      ok: false,
      error: "Paste a complete Discord webhook URL from Channel Settings > Integrations > Webhooks."
    };
  }
  const state = await getState();
  const updates = { alertOnChange: false };

  if (Number.isFinite(intervalMinutes)) {
    updates.intervalMinutes = intervalMinutes;
  }

  if (Array.isArray(keywords)) {
    const selectedCampuses = keywords.filter((campus) =>
      DEFAULT_CAMPUSES.includes(campus)
    );
    const previousSelectableMatches = state.previousSelectableMatches.filter(
      (campus) => selectedCampuses.includes(campus)
    );
    updates.keywords = selectedCampuses;
    updates.previousSelectableMatches = previousSelectableMatches;
    updates.lastMatch = previousSelectableMatches.join(", ");
  }

  if (discordWebhookUrl !== undefined) {
    updates.discordWebhookUrl = discordWebhookUrl;
  }

  await chrome.storage.local.set(updates);
  await schedule({ ...state, ...updates });
  return { ok: true };
}

async function testDiscord(discordWebhookUrl) {
  if (!isDiscordWebhook(discordWebhookUrl)) {
    return { ok: false, error: "Save a valid Discord webhook URL first." };
  }

  try {
    await verifyDiscordWebhook(discordWebhookUrl);
    await postDiscord(
      discordWebhookUrl,
      "Campus Housing Monitor test",
      "Discord alerts are connected.",
      false
    );
    await chrome.storage.local.set({ discordWebhookUrl });
    return { ok: true };
  } catch (error) {
    return {
      ok: false,
      error: `Test failed: ${error.message}`
    };
  }
}

async function pingDetectedCampuses() {
  const state = await getState();
  if (!state.lastMatch) {
    return { ok: false, error: "No selected campuses were available on the last check." };
  }

  const title = "Housing campuses are selectable";
  const message = `Currently detected: ${state.lastMatch}. Open the monitored tab to verify.`;
  try {
    await verifyDiscordWebhook(state.discordWebhookUrl);
    const pingEveryone = state.lastMatch
      .split(",")
      .some((campus) => campus.trim().toLowerCase() === "polytechnic");
    await postDiscord(state.discordWebhookUrl, title, message, pingEveryone);
    return { ok: true };
  } catch (error) {
    return { ok: false, error: `Ping failed: ${error.message}` };
  }
}

async function scanNow() {
  const state = await getState();
  if (!state.enabled || !state.tabId) {
    return { ok: false, error: "Start monitoring the housing page first." };
  }
  return scanMonitoredTab(state.tabId);
}

async function focusMonitoredTab() {
  const state = await getState();
  if (!state.enabled || !state.tabId) {
    return { ok: false, error: "No monitored tab is active." };
  }
  try {
    const tab = await chrome.tabs.get(state.tabId);
    await chrome.tabs.update(state.tabId, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
    return { ok: true };
  } catch {
    return { ok: false, error: "The monitored tab was closed." };
  }
}

async function handlePageResult(result, tab) {
  const state = await getState();
  if (!state.enabled || tab?.id !== state.tabId) return { ok: false };

  const selectableMatches = (result.selectableMatches || []).slice().sort();
  const previousMatches = (state.previousSelectableMatches || []).slice().sort();
  const appeared = selectableMatches.filter((campus) => !previousMatches.includes(campus));
  const disappeared = previousMatches.filter((campus) => !selectableMatches.includes(campus));
  const now = new Date().toLocaleString();
  const matched = selectableMatches.length > 0;
  const changed = Boolean(state.baselineHash) && result.hash !== state.baselineHash;
  const campusTransition = appeared.length > 0 || disappeared.length > 0;
  const fingerprint = campusTransition
    ? `appeared:${appeared.join("|")};disappeared:${disappeared.join("|")}`
    : `page:${result.hash}`;
  let lastStatus = matched
    ? `Available now: ${selectableMatches.join(", ")}`
    : changed
      ? "Checked: no selected campuses are available right now."
      : "Checked: no selected campuses are available right now.";

  await chrome.storage.local.set({
    baselineHash: state.baselineHash || result.hash,
    lastChecked: now,
    lastStatus,
    lastMatch: selectableMatches.join(", "),
    previousSelectableMatches: selectableMatches
  });

  if (campusTransition || (changed && state.alertOnChange)) {
    const title = campusTransition ? "Housing availability changed" : "Housing page changed";
    const transitionLines = [];
    if (appeared.length) {
      transitionLines.push(`${appeared.join(", ")} ${appeared.length === 1 ? "is" : "are"} now available.`);
    }
    if (disappeared.length) {
      transitionLines.push(`${disappeared.join(", ")} ${disappeared.length === 1 ? "is" : "are"} no longer available.`);
    }
    const message = campusTransition
      ? `${transitionLines.join(" ")} Open the monitored tab to verify.`
      : "The monitored page content changed. Open the tab to check it.";

    if (fingerprint !== state.desktopAlertFingerprint) {
      await notify(title, message);
      await chrome.storage.local.set({ desktopAlertFingerprint: fingerprint });
    }

    if (
      state.discordWebhookUrl &&
      fingerprint !== state.discordAlertFingerprint &&
      !discordAlertsInProgress.has(fingerprint)
    ) {
      discordAlertsInProgress.add(fingerprint);
      try {
        const pingEveryone = appeared.some(
          (campus) => campus.toLowerCase() === "polytechnic"
        );
        await postDiscord(state.discordWebhookUrl, title, message, pingEveryone);
        await chrome.storage.local.set({ discordAlertFingerprint: fingerprint });
      } catch (error) {
        lastStatus = `${lastStatus} Discord alert failed: ${error.message}`;
        await chrome.storage.local.set({ lastStatus });
      } finally {
        discordAlertsInProgress.delete(fingerprint);
      }
    }
  }

  return { ok: true };
}
