@echo off
title Campus Housing Monitor - Discord Alerts
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0discord-alert-relay.ps1"
pause
