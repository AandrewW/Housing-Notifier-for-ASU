const DEFAULT_CAMPUSES = ["Polytechnic", "Tempe", "Downtown Phoenix", "West"];
const interval = document.querySelector("#interval");
const status = document.querySelector("#status");
const stateDot = document.querySelector("#stateDot");
const startLabel = document.querySelector("#startLabel");
const campusButtons = [...document.querySelectorAll(".campus-toggle")];
const webhookUrl = document.querySelector("#webhookUrl");
const saveWebhook = document.querySelector("#saveWebhook");
const start = document.querySelector("#start");
const stop = document.querySelector("#stop");
const restart = document.querySelector("#restart");
const testDiscord = document.querySelector("#testDiscord");
const pingDetected = document.querySelector("#pingDetected");
const scanNow = document.querySelector("#scanNow");
let transientMessageUntil = 0;

function showMessage(message, duration = 4000) {
  status.textContent = message;
  transientMessageUntil = Date.now() + duration;
}

async function currentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function selectedCampuses() {
  return campusButtons
    .filter((button) => button.classList.contains("selected"))
    .map((button) => button.dataset.campus);
}

function renderCampusButtons(keywords) {
  for (const button of campusButtons) {
    const selected = keywords.includes(button.dataset.campus);
    button.classList.toggle("selected", selected);
    button.setAttribute("aria-pressed", String(selected));
  }
}

function showState(state) {
  status.textContent = state.lastChecked
    ? `${state.lastStatus} | ${state.lastChecked}`
    : state.lastStatus;
  stateDot.classList.toggle("on", state.enabled);
  stateDot.title = state.enabled ? "Monitoring" : "Paused";
  startLabel.textContent = state.enabled ? "Open housing tab" : "Start monitoring";
  stop.disabled = !state.enabled;
  restart.disabled = !state.enabled;
}

async function render() {
  const state = await chrome.storage.local.get({
    enabled: false,
    intervalMinutes: 5,
    keywords: DEFAULT_CAMPUSES,
    discordWebhookUrl: "",
    lastChecked: "",
    lastStatus: "Not monitoring"
  });
  interval.value = String(state.intervalMinutes);
  webhookUrl.value = state.discordWebhookUrl;
  renderCampusButtons(state.keywords);
  showState(state);
}

async function refreshStatus() {
  if (Date.now() < transientMessageUntil) return;
  const state = await chrome.storage.local.get({
    enabled: false,
    lastChecked: "",
    lastStatus: "Not monitoring"
  });
  showState(state);
}

async function saveMonitorSettings(message) {
  const campuses = selectedCampuses();
  const response = await chrome.runtime.sendMessage({
    type: "saveSettings",
    intervalMinutes: Number(interval.value),
    keywords: campuses
  });
  if (!response.ok) {
    showMessage(response.error, 6000);
    return false;
  }
  if (message) showMessage(message);
  return true;
}

async function saveWebhookSetting(message) {
  const response = await chrome.runtime.sendMessage({
    type: "saveSettings",
    discordWebhookUrl: webhookUrl.value.trim()
  });
  if (!response.ok) {
    showMessage(response.error, 6000);
    return false;
  }
  if (message) showMessage(message);
  return true;
}

for (const button of campusButtons) {
  button.addEventListener("click", async () => {
    button.classList.toggle("selected");
    button.setAttribute(
      "aria-pressed",
      String(button.classList.contains("selected"))
    );
    const action = button.classList.contains("selected") ? "is being watched" : "is turned off";
    await saveMonitorSettings(`${button.dataset.campus} ${action}.`);
  });
}

interval.addEventListener("change", () => saveMonitorSettings("Refresh interval saved."));
saveWebhook.addEventListener("click", () => {
  const message = webhookUrl.value.trim()
    ? "Discord webhook saved."
    : "Discord webhook removed.";
  saveWebhookSetting(message);
});
webhookUrl.addEventListener("change", () => {
  const message = webhookUrl.value.trim()
    ? "Discord webhook saved."
    : "Discord webhook removed.";
  saveWebhookSetting(message);
});

start.addEventListener("click", async () => {
  const state = await chrome.storage.local.get({ enabled: false });
  if (state.enabled) {
    const response = await chrome.runtime.sendMessage({ type: "focusMonitoredTab" });
    if (!response.ok) showMessage(response.error, 6000);
    return;
  }
  const tab = await currentTab();
  const response = await chrome.runtime.sendMessage({
    type: "startMonitoring",
    tabId: tab.id,
    url: tab.url,
    intervalMinutes: Number(interval.value),
    keywords: selectedCampuses()
  });
  showMessage(response.ok ? "Starting monitor..." : response.error, response.ok ? 2000 : 6000);
});

restart.addEventListener("click", async () => {
  const state = await chrome.storage.local.get({ tabId: null });
  let tab;
  try {
    tab = await chrome.tabs.get(state.tabId);
  } catch {
    showMessage("The monitored tab was closed.", 6000);
    return;
  }
  const response = await chrome.runtime.sendMessage({
    type: "startMonitoring",
    tabId: tab.id,
    url: tab.url,
    intervalMinutes: Number(interval.value),
    keywords: selectedCampuses()
  });
  showMessage(response.ok ? "Restarting monitor..." : response.error, response.ok ? 2000 : 6000);
});

stop.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "stopMonitoring" });
  await refreshStatus();
});

testDiscord.addEventListener("click", async () => {
  if (!(await saveWebhookSetting())) return;
  showMessage("Testing Discord...", 10000);
  const response = await chrome.runtime.sendMessage({
    type: "testDiscord",
    discordWebhookUrl: webhookUrl.value.trim()
  });
  showMessage(
    response.ok ? "Test message sent to Discord." : response.error,
    response.ok ? 4000 : 6000
  );
});

pingDetected.addEventListener("click", async () => {
  showMessage("Sending current result...", 10000);
  const response = await chrome.runtime.sendMessage({ type: "pingDetectedCampuses" });
  showMessage(
    response.ok ? "Current result sent to Discord." : response.error,
    response.ok ? 4000 : 6000
  );
});

scanNow.addEventListener("click", async () => {
  showMessage("Checking the housing page...", 10000);
  const response = await chrome.runtime.sendMessage({ type: "scanNow" });
  if (!response.ok) {
    showMessage(`Scan failed: ${response.error}`, 6000);
    return;
  }
  const found = response.selectableMatches.length
    ? response.selectableMatches.join(", ")
    : "none";
  showMessage(found === "none"
    ? "No selected campuses are available right now."
    : `Available now: ${found}.`);
});

render();
setInterval(refreshStatus, 1000);
